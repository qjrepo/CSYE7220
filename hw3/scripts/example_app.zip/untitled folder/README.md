# CloudFormationCodeDeployWindowsDemo
Using Cloudformation/CodePipeline/CodeDeploy for deploying a .NETCore 2.0 web application to the Amazon cloud via AWS.  

AWS Powershell toolkit
https://aws.amazon.com/powershell/

The original projects (.NETCore 1 RC2)  that this was based off
https://github.com/awslabs/aws-blog-net-exploring-aspnet-core.git

https://github.com/kousekt/CloudFormationCodeDeployWindowsDemo

The .net core runtime and windows hosting downloads can be found here:
https://dotnet.microsoft.com/download/dotnet-core/2.1 

The bundled dotnetcore+aspdotnetcore runtime + IIS hosting (preferred) is here:
https://dotnet.microsoft.com/download/thank-you/dotnet-runtime-2.1.11-windows-hosting-bundle-installer 

I've included my georgemichaellastxmas publish folder, but you need to replace that with your own web site's publish folder!
